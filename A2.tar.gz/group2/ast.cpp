#include "ast.hh"

abstract_astnode::abstract_astnode() : type() {
    node_type = ABSTRACT_ASTNODE;
}

statement_astnode::statement_astnode() {
    node_type = STATEMENT_ASTNODE;
}

exp_astnode::exp_astnode() {
    node_type = EXP_ASTNODE;
}

ref_astnode::ref_astnode() {
    node_type = REF_ASTNODE;
}

empty_astnode::empty_astnode() {
    node_type = EMPTY_ASTNODE;
}

seq_astnode::seq_astnode() {
    node_type = SEQ_ASTNODE;
    vec_stmt_astnode.clear();
}

assignS_astnode::assignS_astnode() {
    node_type = ASSIGNS_ASTNODE;
}

return_astnode::return_astnode() {
    node_type = RETURN_ASTNODE;
}

proccall_astnode::proccall_astnode() {
    node_type = PROCCALL_ASTNODE;
    vec_exp_astnode.clear();
}

if_astnode::if_astnode() {
    node_type = IF_ASTNODE;
}

while_astnode::while_astnode() {
    node_type = WHILE_ASTNODE;
}

for_astnode::for_astnode() {
    node_type = FOR_ASTNODE;
}

op_binary_astnode::op_binary_astnode() {
    node_type = OP_BINARY_ASTNODE;
}

op_unary_astnode::op_unary_astnode() {
    node_type = OP_UNARY_ASTNODE;
}

assignE_astnode::assignE_astnode() {
    node_type = ASSIGNE_ASTNODE;
}

funcall_astnode::funcall_astnode() {
    node_type = FUNCALL_ASTNODE;
    vec_exp_astnode.clear();
}

floatconst_astnode::floatconst_astnode() {
    node_type = FLOATCONST_ASTNODE;
}

intconst_astnode::intconst_astnode() {
    node_type = INTCONST_ASTNODE;
}

string_astnode::string_astnode() {
    node_type = STRING_ASTNODE;
}

identifier_astnode::identifier_astnode() {
    node_type = IDENTIFIER_ASTNODE;
}

member_astnode::member_astnode() {
    node_type = MEMBER_ASTNODE;
}

arrow_astnode::arrow_astnode() {
    node_type = ARROW_ASTNODE;
}

arrayref_astnode::arrayref_astnode() {
    node_type = ARRAYREF_ASTNODE;
}

void empty_astnode::print() {
    cout << "\"empty\"" << endl;
}

void seq_astnode::print() {
    cout << "{" << endl;
    cout << "\"seq\":" << endl;
    cout << "[" << endl;
    for(size_t i=0; i<vec_stmt_astnode.size(); i++) {
        vec_stmt_astnode[i]->print();
        if(i!=vec_stmt_astnode.size()-1) {
            cout << "," << endl;
        }
        cout << endl;
    }
    cout << "]" << endl;
    cout << "}" << endl;
}

assignS_astnode::assignS_astnode(exp_astnode* left, exp_astnode* right) {
    node_type = ASSIGNS_ASTNODE;
    this->left = left;
    this->right = right;
}

void assignS_astnode::print() {
    cout << "{" << endl;
    cout << "\"assignS\":" << endl;
    cout << "{" << endl;
    cout << "\"left\":" << endl;
    left->print();
    cout << "," << endl;
    cout << "\"right\":" << endl;
    right->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

void return_astnode::print() {
    cout << "{" << endl;
    cout << "\"return\":" << endl;
    ret->print();
    cout << "}" << endl;
}

return_astnode::return_astnode(exp_astnode* ret) {
    node_type = RETURN_ASTNODE;
    this->ret = ret;
}

void proccall_astnode::print() {            // need to check size>0?
    cout << "{" << endl;
    cout << "\"proccall\":" << endl;
    cout << "{" << endl;
    cout << "\"fname\":" << endl;
    vec_exp_astnode[0]->print();
    cout << "," << endl;
    cout << "\"params\":" << endl;
    cout << "[" << endl;
    for(size_t i=1; i<vec_exp_astnode.size(); i++) {
        vec_exp_astnode[i]->print();
        if(i!=vec_exp_astnode.size()-1) {
            cout << "," << endl;
        }
    }
    cout << "]" << endl;
    cout << "}" << endl;
    cout << "}" << endl;
}

void if_astnode::print() {
    cout << "{" << endl;
    cout << "\"if\":" << endl;
    cout << "{" << endl;
    cout << "\"cond\":" << endl;
    cond->print();
    cout << "," << endl;
    cout << "\"then\":" << endl;
    then_node->print();
    cout << "," << endl;
    cout << "\"else\":" << endl;
    else_node->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

if_astnode::if_astnode(exp_astnode* cond, statement_astnode* then_node, statement_astnode* else_node) {
    node_type = IF_ASTNODE;
    this->cond = cond;
    this->then_node = then_node;
    this->else_node = else_node;
}

void while_astnode::print() {
    cout << "{" << endl;
    cout << "\"while\":" << endl;
    cout << "{" << endl;
    cout << "\"cond\":" << endl;
    cond->print();
    cout << "," << endl;
    cout << "\"stmt\":" << endl;
    stmt->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

while_astnode::while_astnode(exp_astnode* cond, statement_astnode* stmt) {
    node_type = WHILE_ASTNODE;
    this->cond = cond;
    this->stmt = stmt;
}

void for_astnode::print() {
    cout << "{" << endl;
    cout << "\"for\":" << endl;
    cout << "{" << endl;
    cout << "\"init\":" << endl;
    init->print();
    cout << "," << endl;
    cout << "\"guard\":" << endl;
    guard->print();
    cout << "," << endl;
    cout << "\"step\":" << endl;
    step->print();
    cout << "," << endl;
    cout << "\"body\":" << endl;
    body->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

for_astnode::for_astnode(exp_astnode* init, exp_astnode* guard, exp_astnode* step, statement_astnode* body) {
    node_type = FOR_ASTNODE;
    this->init = init;
    this->guard = guard;
    this->step = step;
    this->body = body;
}

void op_binary_astnode::print() {
    cout << "{" << endl;
    cout << "\"op_binary\":" << endl;
    cout << "{" << endl;
    cout << "\"op\":" << endl;
    cout << "\"" << op << "\"" << endl;
    cout << "," << endl;
    cout << "\"left\":" << endl;
    left->print();
    cout << "," << endl;
    cout << "\"right\":" << endl;
    right->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

op_binary_astnode::op_binary_astnode(string op, exp_astnode* left, exp_astnode* right) {
    node_type = OP_BINARY_ASTNODE;
    this->op = op;
    this->left = left;
    this->right = right;
}

void op_unary_astnode::print() {
    cout << "{" << endl;
    cout << "\"op_unary\":" << endl;
    cout << "{" << endl;
    cout << "\"op\":" << endl;
    cout << "\"" << op << "\"" << endl;
    cout << "," << endl;
    cout << "\"child\":" << endl;
    child->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

op_unary_astnode::op_unary_astnode(string op, exp_astnode* child) {
    node_type = OP_UNARY_ASTNODE;
    this->op = op;
    this->child = child;
}

void assignE_astnode::print() {
    cout << "{" << endl;
    cout << "\"assignE\":" << endl;
    cout << "{" << endl;
    cout << "\"left\":" << endl;
    left->print();
    cout << "," << endl;
    cout << "\"right\":" << endl;
    right->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

assignE_astnode::assignE_astnode(exp_astnode* left, exp_astnode* right) {
    node_type = ASSIGNE_ASTNODE;
    this->left = left;
    this->right = right;
}

void funcall_astnode::print() {             // similar to proccall, need to check size>0?
    cout << "{" << endl;
    cout << "\"funcall\":" << endl;
    cout << "{" << endl;
    cout << "\"fname\":" << endl;
    vec_exp_astnode[0]->print();
    cout << "," << endl;
    cout << "\"params\":" << endl;
    cout << "[" << endl;
    for(size_t i=1; i<vec_exp_astnode.size(); i++) {
        vec_exp_astnode[i]->print();
        if(i!=vec_exp_astnode.size()-1) {
            cout << "," << endl;
        }
    }
    cout << "]" << endl;
    cout << "}" << endl;
    cout << "}" << endl;
}

void floatconst_astnode::print() {
    cout << "{" << endl;
    cout << "\"floatconst\":" << endl;
    cout << f << endl;
    cout << "}" << endl;
}

floatconst_astnode::floatconst_astnode(float f) {
    node_type = FLOATCONST_ASTNODE;
    this->f = f;
}

void intconst_astnode::print() {
    cout << "{" << endl;
    cout << "\"intconst\":" << endl;
    cout << in << endl;
    cout << "}" << endl;
}

intconst_astnode::intconst_astnode(int in) {
    node_type = INTCONST_ASTNODE;
    this->in = in;
}

void string_astnode::print() {
    cout << "{" << endl;
    cout << "\"stringconst\":" << endl;
    cout << s << endl;      // string_astnode created from STRING_LITERAL
                            // so it already has quotes
    cout << "}" << endl;
}

string_astnode::string_astnode(string s) {
    node_type = STRING_ASTNODE;
    this->s = s;
}

void identifier_astnode::print() {
    cout << "{" << endl;
    cout << "\"identifier\":" << endl;
    cout << "\"" << s << "\"" << endl;
    cout << "}" << endl;
}

identifier_astnode::identifier_astnode(string s) {
    node_type = IDENTIFIER_ASTNODE;
    this->s = s;
}

void member_astnode::print() {
    cout << "{" << endl;
    cout << "\"member\":" << endl;
    cout << "{" << endl;
    cout << "\"struct\":" << endl;
    struct_name->print();
    cout << "," << endl;
    cout << "\"field\":" << endl;
    field->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

member_astnode::member_astnode(exp_astnode* struct_name, identifier_astnode* field) {
    node_type = MEMBER_ASTNODE;
    this->struct_name = struct_name;
    this->field = field;
}

void arrow_astnode::print() {
    cout << "{" << endl;
    cout << "\"arrow\":" << endl;
    cout << "{" << endl;
    cout << "\"pointer\":" << endl;
    pointer->print();
    cout << "," << endl;
    cout << "\"field\":" << endl;
    field->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

arrow_astnode::arrow_astnode(exp_astnode* pointer, identifier_astnode* field) {
    node_type = ARROW_ASTNODE;
    this->pointer = pointer;
    this->field = field;
}

void arrayref_astnode::print() {
    cout << "{" << endl;
    cout << "\"arrayref\":" << endl;
    cout << "{" << endl;
    cout << "\"array\":" << endl;
    array->print();
    cout << "," << endl;
    cout << "\"index\":" << endl;
    index->print();
    cout << "}" << endl;
    cout << "}" << endl;
}

arrayref_astnode::arrayref_astnode(exp_astnode* array, exp_astnode* index) {
    node_type = ARRAYREF_ASTNODE;
    this->array = array;
    this->index = index;
}

pair<bool,exp_astnode*> compatible_convert(exp_astnode* node, Type* type_ptr) {
    string given_type = node->type.get_type();
    string req_type = type_ptr->get_type();     // required type

    // cout << "compatible_convert: " << given_type << ' ' << req_type << endl;

    // same, and pointer<->void*
    if(
        (given_type == req_type) ||
        (node->type.is_array_or_pointer() && req_type=="void*") ||
        (type_ptr->is_array_or_pointer() && given_type=="void*")
    ) return {true,node};

    // int<->float
    if(given_type=="int" && req_type=="float") {        // "int" => node must be (derived of) exp_astnode
        op_unary_astnode* new_node = new op_unary_astnode("TO_FLOAT", node);
        new_node->type = Type(req_type);
        return {true,new_node};
    }
    else if(given_type=="float" && req_type=="int") {
        op_unary_astnode* new_node = new op_unary_astnode("TO_INT", node);
        new_node->type = Type(req_type);
        return {true,new_node};
    }

    // array->pointer [via decay]
    if(node->type.is_array()) {
        node->type.decay_array_to_pointer();
        if(node->type.get_type() == req_type) return {true,node};
    }

    return {false,nullptr};
}